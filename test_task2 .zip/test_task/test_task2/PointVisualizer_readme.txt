Usage notes:
- execute PointVisualizer.exe with command line argument of ascii point file
- drag and drop ascii point file onto executeable

Linux note: you need to have GLFW libraries (version 3 or greater) installed
